1. Put your raw fastq file inside /RawSeq
# You must gunzip fastq.gz to fastq for the script to work.
# The script will auto filter reads based on QC>30 and nt=110. You can change this in 1_Amplicon.pbs where involves command for fastp and seqtk.

2. Modify Demultiplex.csv in Deplex folder to input your criteria:
1st column: sample name, it will sort and output deplexed fastq as the name you provide
2nd column: start pattern, pattern you use to recognize your individual sample, it will be trimmed from the final output
3rd column: include pattern, pattern which must include in your reads as second criteria
This script extracts the sequence between the end of the start pattern and the start of the contain pattern
you may have multiple rows in the csv file it will give you multiple samples.

3. Modify Addsequence.csv in Analyze folder to input your criteria:	
1st column: contain all sample file name the script just deplexed. 
2nd column: reference_sequence you wish to compare and analyze
3rd column: partial_sequence that is within reference_sequence 
# This may include intron 
4th column: Intron on the left most side of reads (and partial_sequence)
5th column: Intron inbetween reads (and partial_sequence)
6th column: Intron on the right most side reads (and partial_sequence)
# Intron column may left blank
# When checking for stop codon position, partial_sequence with intron removed will be matched to reference_sequence and replaced with your reads with intron removed

4. Open 1_Amplicon.pbs and edit sourcedir to the directory of this folder
# The line you edit is:
	## Edit sourcedir to the directory of this folder
	export sourcedir=/Edit this to your directory

5. Submit 1_Amplicon.pbs in the login node
# Use this command: qsub 1_Amplicon.pbs
# The output result as csv will be in the current directory
# You can check (your raw fastq file name)_read_assignment_counts.txt in Deplex folder to check reads assign rate.


## Raw fastq filter command:
#Filter QC>30,nt>110:
fastp -i Sample-1_S1_L001_R1_001.fastq -o temp_filtered.fastq -q 30 -l 110 -L 110
#Filter nt=110
seqtk seq -L 110 temp_filtered.fastq > final_filtered.fastq
