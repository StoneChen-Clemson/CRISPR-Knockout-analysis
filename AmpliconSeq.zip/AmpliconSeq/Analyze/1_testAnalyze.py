import pandas as pd
from Bio import SeqIO
from Bio.Seq import Seq
import os

def pad_to_codon_length(sequence):
    # Pad with 'N' up to two nucleotides to make the length a multiple of 3
    remainder = len(sequence) % 3
    if remainder != 0:
        sequence += 'N' * (3 - remainder)  # add 1 or 2 'N' as needed, but not more
    return sequence

def process_fastq(row):
    fastq_file = row['fastq_file']
    if not fastq_file.lower().endswith('.fastq'):
        fastq_file += '.fastq'
    fastq_file_path = os.path.join(os.getcwd(), fastq_file)

    ref_seq, part_seq = row['reference_sequence'], row['partial_sequence']
    introns = {
        'left': row.get('left_intron', ''),
        'mid': row.get('mid_intron', ''),
        'right': row.get('right_intron', '')
    }

    WT_count, Indel_count, splicing_mut_count = 0, 0, 0
    Indel_lengths = {}
    stop_codon_positions = {}
    no_stop_codon_count = 0
    total_reads = 0

    try:
        for record in SeqIO.parse(fastq_file_path, 'fastq'):
            total_reads += 1
            read_seq = str(record.seq)
            is_splicing_mut = False

            if part_seq in read_seq:
                WT_count += 1
            else:
                Indel_count += 1
                indel_length = len(read_seq) - len(part_seq)
                Indel_lengths[indel_length] = Indel_lengths.get(indel_length, 0) + 1

                if (introns['left'] and not read_seq.startswith(introns['left'])) or \
                   (introns['right'] and not read_seq.endswith(introns['right'])) or \
                   (introns['mid'] and introns['mid'] not in read_seq):
                    is_splicing_mut = True
                    splicing_mut_count += 1

                if not is_splicing_mut:
                    if introns['left'] and read_seq.startswith(introns['left']):
                        read_seq = read_seq[len(introns['left']):]
                    if introns['mid'] and introns['mid'] in read_seq:
                        read_seq = read_seq.replace(introns['mid'], '', 1)
                    if introns['right'] and read_seq.endswith(introns['right']):
                        read_seq = read_seq[:-len(introns['right'])]

                    modified_part_seq = part_seq
                    if introns['left'] and modified_part_seq.startswith(introns['left']):
                        modified_part_seq = modified_part_seq[len(introns['left']):]
                    if introns['mid'] and introns['mid'] in modified_part_seq:
                        modified_part_seq = modified_part_seq.replace(introns['mid'], '', 1)
                    if introns['right'] and modified_part_seq.endswith(introns['right']):
                        modified_part_seq = modified_part_seq[:-len(introns['right'])]

                    start_index = ref_seq.find(modified_part_seq)
                    end_index = start_index + len(modified_part_seq)
                    if start_index != -1 and end_index != -1:
                        read_seq = ref_seq[:start_index] + read_seq + ref_seq[end_index:]

                    read_seq = pad_to_codon_length(read_seq)  # Pad instead of trimming to multiple of 3
                    translated_seq = Seq(read_seq).translate(to_stop=False)
                    stop_codon_index = str(translated_seq).find('*')
                    if stop_codon_index == -1:
                        no_stop_codon_count += 1
                    else:
                        stop_codon_positions[stop_codon_index] = stop_codon_positions.get(stop_codon_index, 0) + 1

    except FileNotFoundError:
        print(f"File not found: {fastq_file_path}")
        return

    data = [
        ('WT_count', WT_count),
        ('WT_percentage', WT_count / total_reads * 100 if total_reads else 0),
        ('Indel_count', Indel_count),
        ('Indel_percentage', Indel_count / total_reads * 100 if total_reads else 0),
        ('splicing_mutation', splicing_mut_count),
        ('no_stop_codon', no_stop_codon_count)
    ]
    
    for length, count in Indel_lengths.items():
        data.append((f'Indel_length_diff_{length}', count))
    
    for pos, count in stop_codon_positions.items():
        data.append((f'Stop_codon_at_pos_{pos}', count))

    df = pd.DataFrame(data, columns=['Statistic', 'Value'])
    output_filename = os.path.splitext(os.path.basename(fastq_file))[0] + '_output.csv'
    df.to_csv(output_filename, index=False)

# Load CSV
df = pd.read_csv('AddSequence.csv').fillna('')

for index, row in df.iterrows():
    process_fastq(row)
