import csv
import re
import os
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
import glob

def pattern_to_regex(pattern):
    """Converts a nucleotide pattern into a regex object, treating 'N' as any nucleotide."""
    return re.compile(pattern.replace('N', '[ATCG]'))

def contained_pattern_to_regex(pattern):
    """Creates a regex object for the contain pattern, 'N' matches any nucleotide."""
    if pattern:
        return re.compile(pattern.replace('N', '[ATCG]'))
    else:
        return re.compile('.*')  # Matches any sequence if the contain pattern is empty

# Read demultiplexing patterns, sample names, and contain patterns from CSV
patterns = {}
with open('Demultiplex.csv', 'r') as csvfile:
    reader = csv.reader(csvfile)
    next(reader, None)  # Skip the header
    for row in reader:
        sample_name, start_pattern, contain_pattern = row
        patterns[(pattern_to_regex(start_pattern), contained_pattern_to_regex(contain_pattern))] = sample_name

# Initialize counters and track output filenames
output_filenames = []

# Process each FASTQ file in the directory
for fastq_file_name in glob.glob('*.fastq'):
    counters = {sample_name: 0 for sample_name in set(patterns.values())}
    unassigned = 0
    with open(fastq_file_name, 'r') as fastq_file:
        for record in SeqIO.parse(fastq_file, 'fastq'):
            seq = str(record.seq)
            assigned = False
            for (start_pattern, contain_pattern), sample_name in patterns.items():
                match_start = start_pattern.search(seq)
                match_contain = contain_pattern.search(seq, match_start.end() if match_start else 0)
                if match_start and match_contain:
                    # Extract the sequence between the start and contain patterns
                    between_seq = seq[match_start.end():match_contain.start()]
                    new_record = SeqRecord(Seq(between_seq),
                                           id=record.id,
                                           name=record.name,
                                           description=record.description)
                    # Adjust quality scores if present
                    if 'phred_quality' in record.letter_annotations:
                        between_qual = record.letter_annotations['phred_quality'][match_start.end():match_contain.start()]
                        new_record.letter_annotations['phred_quality'] = between_qual

                    output_filename = f'{sample_name}.fastq'
                    with open(output_filename, 'a') as out_file:
                        SeqIO.write(new_record, out_file, 'fastq')
                    if output_filename not in output_filenames:
                        output_filenames.append(output_filename)

                    counters[sample_name] += 1
                    assigned = True
                    break  # Break after the first match
            if not assigned:
                unassigned += 1

    # Output read assignment counts for each file
    with open(f'{fastq_file_name}_read_assignment_counts.txt', 'w') as counts_file:
        for sample_name, count in counters.items():
            counts_file.write(f'{sample_name}: {count} reads\n')
        counts_file.write(f'Unassigned: {unassigned} reads\n')

# Output the filenames of created FASTQ files
with open('output_filenames.csv', 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    for filename in output_filenames:
        writer.writerow([filename, ''])  # Leave the second column blank

print('Sorting complete. Counts and output filenames have been written.')
