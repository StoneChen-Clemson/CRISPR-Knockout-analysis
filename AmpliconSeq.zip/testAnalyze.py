import pandas as pd
from Bio import SeqIO
from Bio.Seq import Seq
import os
import csv
def pad_to_codon_length(sequence):
    """Pad the sequence with 'N' (up to 2 bases) so its length is a multiple of 3."""
    remainder = len(sequence) % 3
    if remainder != 0:
        sequence += 'N' * (3 - remainder)
    return sequence
def compute_protein_length_upto_first_stop(protein_str):
    """
    Returns the amino-acid length up to the first stop codon.
    (Since we translate with to_stop=True, the protein string already stops at the stop codon.)
    """
    return len(protein_str)
def process_fastq(row):
    fastq_file = row['fastq_file']
    if not fastq_file.lower().endswith('.fastq'):
        fastq_file += '.fastq'
    fastq_file_path = os.path.join(os.getcwd(), fastq_file)
    base_name = os.path.splitext(os.path.basename(fastq_file))[0]
    ref_seq = row['reference_sequence']
    part_seq = row['partial_sequence']
    introns = {
        'left': row.get('left_intron', ''),
        'mid': row.get('mid_intron', ''),
        'right': row.get('right_intron', '')
    }
    start_codon_idx = ref_seq.find("ATG")
    if start_codon_idx != -1:
        coding_ref_seq = ref_seq[start_codon_idx:]
    else:
        coding_ref_seq = ref_seq
    coding_ref_seq = pad_to_codon_length(coding_ref_seq)
    translated_ref_seq = Seq(coding_ref_seq).translate(to_stop=True)
    ref_protein_len = len(translated_ref_seq)
    total_reads = 0
    WT_count = 0
    Indel_count = 0
    splicing_mut_count = 0
    silent_mutation_count = 0
    unassigned_count = 0
    partial_reconstruction_failure_count = 0
    Indel_lengths = {}
    truncation_count = 0
    amino_acid_mutation_count = 0
    no_stop_codon_count = 0
    WT_reads = []
    Indel_reads = []
    Splicing_reads = []
    Silent_reads = []
    Truncation_reads = []
    AA_mutation_reads = []
    No_stop_reads = []
    Unassigned_reads = []
    try:
        for record in SeqIO.parse(fastq_file_path, 'fastq'):
            total_reads += 1
            read_id = record.id
            read_seq = str(record.seq)
            if part_seq in read_seq:
                WT_count += 1
                WT_reads.append((read_id, read_seq))
            else:
                Indel_count += 1
                length_diff = len(read_seq) - len(part_seq)
                Indel_lengths[length_diff] = Indel_lengths.get(length_diff, 0) + 1
                Indel_reads.append((read_id, read_seq, length_diff))
                is_splicing_mut = False
                if (introns['left'] and not read_seq.startswith(introns['left'])) or \
                   (introns['right'] and not read_seq.endswith(introns['right'])) or \
                   (introns['mid'] and introns['mid'] not in read_seq):
                    splicing_mut_count += 1
                    Splicing_reads.append((read_id, read_seq))
                    is_splicing_mut = True
                is_silent = False
                if not is_splicing_mut and len(read_seq) == len(part_seq):
                    temp_read_seq = read_seq
                    if introns['left'] and temp_read_seq.startswith(introns['left']):
                        temp_read_seq = temp_read_seq[len(introns['left']):]
                    if introns['mid'] and introns['mid'] in temp_read_seq:
                        temp_read_seq = temp_read_seq.replace(introns['mid'], '', 1)
                    if introns['right'] and temp_read_seq.endswith(introns['right']):
                        temp_read_seq = temp_read_seq[:-len(introns['right'])]
                    modified_part_seq = part_seq
                    if introns['left'] and modified_part_seq.startswith(introns['left']):
                        modified_part_seq = modified_part_seq[len(introns['left']):]
                    if introns['mid'] and introns['mid'] in modified_part_seq:
                        modified_part_seq = modified_part_seq.replace(introns['mid'], '', 1)
                    if introns['right'] and modified_part_seq.endswith(introns['right']):
                        modified_part_seq = modified_part_seq[:-len(introns['right'])]
                    start_index = ref_seq.find(modified_part_seq)
                    end_index = start_index + len(modified_part_seq)
                    if start_index != -1:
                        reconstructed_full = ref_seq[:start_index] + temp_read_seq + ref_seq[end_index:]
                        start_codon_idx_silent = reconstructed_full.find("ATG")
                        if start_codon_idx_silent != -1:
                            coding_reconstructed_full = reconstructed_full[start_codon_idx_silent:]
                        else:
                            coding_reconstructed_full = reconstructed_full
                        coding_reconstructed_full = pad_to_codon_length(coding_reconstructed_full)
                        translated_reconstructed = Seq(coding_reconstructed_full).translate(to_stop=True)
                        if str(translated_reconstructed) == str(translated_ref_seq):
                            silent_mutation_count += 1
                            prot_len = len(translated_reconstructed)
                            Silent_reads.append((read_id, read_seq, str(translated_reconstructed), prot_len))
                            is_silent = True
                if not is_splicing_mut and not is_silent:
                    temp_read_seq = read_seq
                    if introns['left'] and temp_read_seq.startswith(introns['left']):
                        temp_read_seq = temp_read_seq[len(introns['left']):]
                    if introns['mid'] and introns['mid'] in temp_read_seq:
                        temp_read_seq = temp_read_seq.replace(introns['mid'], '', 1)
                    if introns['right'] and temp_read_seq.endswith(introns['right']):
                        temp_read_seq = temp_read_seq[:-len(introns['right'])]
                    modified_part_seq = part_seq
                    if introns['left'] and modified_part_seq.startswith(introns['left']):
                        modified_part_seq = modified_part_seq[len(introns['left']):]
                    if introns['mid'] and introns['mid'] in modified_part_seq:
                        modified_part_seq = modified_part_seq.replace(introns['mid'], '', 1)
                    if introns['right'] and modified_part_seq.endswith(introns['right']):
                        modified_part_seq = modified_part_seq[:-len(introns['right'])]
                    start_index = ref_seq.find(modified_part_seq)
                    if start_index == -1:
                        partial_reconstruction_failure_count += 1
                        continue
                    end_index = start_index + len(modified_part_seq)
                    if end_index > len(ref_seq):
                        partial_reconstruction_failure_count += 1
                        continue
                    reconstructed_read = ref_seq[:start_index] + temp_read_seq + ref_seq[end_index:]
                    start_codon_idx = reconstructed_read.find("ATG")
                    if start_codon_idx != -1:
                        coding_reconstructed_read = reconstructed_read[start_codon_idx:]
                    else:
                        coding_reconstructed_read = reconstructed_read
                    coding_reconstructed_read = pad_to_codon_length(coding_reconstructed_read)
                    translated_seq = Seq(coding_reconstructed_read).translate(to_stop=True)
                    prot_len = len(translated_seq)
                    if prot_len < len(translated_ref_seq):
                        truncation_count += 1
                        nt_cutoff = prot_len * 3
                        truncated_nuc_seq = coding_reconstructed_read[:nt_cutoff]
                        partial_translation = str(translated_seq)
                        Truncation_reads.append((read_id, truncated_nuc_seq, partial_translation, prot_len))
                    else:
                        amino_acid_mutation_count += 1
                        AA_mutation_reads.append((read_id, coding_reconstructed_read, str(translated_seq), prot_len))
    except FileNotFoundError:
        print(f"File not found: {fastq_file_path}")
        return
    data = [
        ('Total_reads', total_reads),
        ('WT_count', WT_count),
        ('WT_percentage', WT_count / total_reads * 100 if total_reads else 0),
        ('Indel_count', Indel_count),
        ('Indel_percentage', Indel_count / total_reads * 100 if total_reads else 0),
        ('uncharacterized splice site-proximal intronic mutation', splicing_mut_count),
        ('truncation_count', truncation_count),
        ('amino_acid_mutation_count', amino_acid_mutation_count),
        ('no_stop_codon_count', no_stop_codon_count),
        ('silent_mutation_count', silent_mutation_count),
        ('unassigned_reads', unassigned_count),
        ('partial_reconstruction_failure_count', partial_reconstruction_failure_count),
    ]
    for length_diff, count_val in Indel_lengths.items():
        data.append((f'Indel_length_diff_{length_diff}', count_val))
    df = pd.DataFrame(data, columns=['Statistic', 'Value'])
    summary_csv = f"{base_name}_summary.csv"
    df.to_csv(summary_csv, index=False)
    def write_protein_csv(filename, rows, second_col_header="ReconstructedSequence"):
        with open(filename, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["ReadID", second_col_header, "TranslatedProtein", "ProteinLength"])
            writer.writerow(["Reference", ref_seq, str(translated_ref_seq), ref_protein_len])
            for (rid, nseq, tprot, plen) in rows:
                writer.writerow([rid, nseq, tprot, plen])
    if WT_reads:
        wt_csv = f"{base_name}_WT_reads.csv"
        with open(wt_csv, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["ReadID", "ReadSequence"])
            for rid, rseq in WT_reads:
                writer.writerow([rid, rseq])
    if Indel_reads:
        indel_csv = f"{base_name}_Indel_reads.csv"
        with open(indel_csv, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["ReadID", "ReadSequence", "LengthDiff"])
            for rid, rseq, ldiff in Indel_reads:
                writer.writerow([rid, rseq, ldiff])
    if Splicing_reads:
        splicing_csv = f"{base_name}_Splicing_mutation_reads.csv"
        with open(splicing_csv, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["ReadID", "ReadSequence"])
            for rid, rseq in Splicing_reads:
                writer.writerow([rid, rseq])
    if Truncation_reads:
        trunc_csv = f"{base_name}_Truncation_mutation_reads.csv"
        write_protein_csv(trunc_csv, Truncation_reads, second_col_header="TruncatedNucSeq")
    if AA_mutation_reads:
        aa_csv = f"{base_name}_AminoAcid_mutation_reads.csv"
        write_protein_csv(aa_csv, AA_mutation_reads)
    if No_stop_reads:
        nostop_csv = f"{base_name}_NoStopCodon_reads.csv"
        write_protein_csv(nostop_csv, No_stop_reads)
    if Silent_reads:
        silent_csv = f"{base_name}_Silent_mutation_reads.csv"
        with open(silent_csv, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["ReadID", "OriginalReadSequence", "TranslatedProtein", "ProteinLength"])
            writer.writerow(["Reference", ref_seq, str(translated_ref_seq), ref_protein_len])
            for (rid, rseq, tprot, plen) in Silent_reads:
                writer.writerow([rid, rseq, tprot, plen])
    if Unassigned_reads:
        unassigned_csv = f"{base_name}_Unassigned_reads.csv"
        with open(unassigned_csv, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["ReadID", "ReadSequence"])
            for rid, rseq in Unassigned_reads:
                writer.writerow([rid, rseq])
df = pd.read_csv('AddSequence.csv').fillna('')
for index, row in df.iterrows():
    process_fastq(row)
