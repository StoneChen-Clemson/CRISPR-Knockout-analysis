import csv
import re
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
import glob

def pattern_to_regex(pattern):
    return re.compile(pattern.replace('N', '[ATCG]'))

def contained_pattern_to_regex(pattern):
    if pattern:
        return re.compile(pattern.replace('N', '[ATCG]'))
    else:
        return None

patterns = {}
with open('Demultiplex.csv', 'r') as csvfile:
    reader = csv.reader(csvfile)
    next(reader, None)
    for row in reader:
        sample_name, start_pattern, contain_pattern, insert_len_str = row
        insert_length = 0
        insert_len_str = insert_len_str.strip()
        if insert_len_str.isdigit():
            insert_length = int(insert_len_str)
        patterns[(pattern_to_regex(start_pattern), contained_pattern_to_regex(contain_pattern), insert_length)] = sample_name

total_counters = {sample_name: 0 for sample_name in set(patterns.values())}
output_files = {sample_name: open(f"{sample_name}.fastq", "a") for sample_name in total_counters}
unique_seq_counts = {sample_name: {} for sample_name in total_counters}
file_counters = {}
output_fastq_filenames = {f"{sample_name}.fastq" for sample_name in total_counters}

for fastq_file_name in glob.glob("*.fastq"):
    if fastq_file_name in output_fastq_filenames:
        continue
    file_counters[fastq_file_name] = {sample_name: 0 for sample_name in total_counters}
    unassigned = 0
    with open(fastq_file_name, "r") as fastq_file:
        for record in SeqIO.parse(fastq_file, "fastq"):
            seq = str(record.seq)
            assigned = False
            for (start_regex, contain_regex, insert_length), sample_name in patterns.items():
                match_start = start_regex.search(seq)
                if match_start:
                    if contain_regex:
                        match_contain = contain_regex.search(seq, match_start.end())
                        while match_contain and not assigned:
                            between_seq = seq[match_start.end():match_contain.start()]
                            if insert_length == 0 or len(between_seq) == insert_length:
                                new_record = SeqRecord(
                                    Seq(between_seq),
                                    id=record.id,
                                    name=record.name,
                                    description=record.description
                                )
                                if "phred_quality" in record.letter_annotations:
                                    between_qual = record.letter_annotations["phred_quality"][match_start.end():match_contain.start()]
                                    new_record.letter_annotations["phred_quality"] = between_qual
                                SeqIO.write(new_record, output_files[sample_name], "fastq")
                                total_counters[sample_name] += 1
                                file_counters[fastq_file_name][sample_name] += 1
                                unique_seq_counts[sample_name][between_seq] = unique_seq_counts[sample_name].get(between_seq, 0) + 1
                                assigned = True
                            else:
                                match_contain = contain_regex.search(seq, match_contain.start() + 1)
                        if assigned:
                            break
                    else:
                        if insert_length == 0:
                            trimmed_seq = seq[match_start.end():]
                            new_record = SeqRecord(
                                Seq(trimmed_seq),
                                id=record.id,
                                name=record.name,
                                description=record.description
                            )
                            if "phred_quality" in record.letter_annotations:
                                trimmed_qual = record.letter_annotations["phred_quality"][match_start.end():]
                                new_record.letter_annotations["phred_quality"] = trimmed_qual
                            SeqIO.write(new_record, output_files[sample_name], "fastq")
                            total_counters[sample_name] += 1
                            file_counters[fastq_file_name][sample_name] += 1
                            unique_seq_counts[sample_name][trimmed_seq] = unique_seq_counts[sample_name].get(trimmed_seq, 0) + 1
                            assigned = True
                        else:
                            start_pos = match_start.end()
                            end_pos = start_pos + insert_length
                            if len(seq) >= end_pos:
                                trimmed_seq = seq[start_pos:end_pos]
                                new_record = SeqRecord(
                                    Seq(trimmed_seq),
                                    id=record.id,
                                    name=record.name,
                                    description=record.description
                                )
                                if "phred_quality" in record.letter_annotations:
                                    trimmed_qual = record.letter_annotations["phred_quality"][start_pos:end_pos]
                                    new_record.letter_annotations["phred_quality"] = trimmed_qual
                                SeqIO.write(new_record, output_files[sample_name], "fastq")
                                total_counters[sample_name] += 1
                                file_counters[fastq_file_name][sample_name] += 1
                                unique_seq_counts[sample_name][trimmed_seq] = unique_seq_counts[sample_name].get(trimmed_seq, 0) + 1
                                assigned = True
                        if assigned:
                            break
            if not assigned:
                unassigned += 1
    file_counters[fastq_file_name]["Unassigned"] = unassigned

for file in output_files.values():
    file.close()

with open("read_assignment_counts.txt", "w") as counts_file:
    counts_file.write("Per File Read Assignment Counts:\n")
    for fastq_file, counts in file_counters.items():
        counts_file.write(f"File: {fastq_file}\n")
        for sample_name, count in counts.items():
            counts_file.write(f"  {sample_name}: {count} reads\n")
        counts_file.write("\n")
    counts_file.write("Total Read Assignment Counts:\n")
    for sample_name, count in total_counters.items():
        counts_file.write(f"{sample_name}: {count} reads\n")

for sample_name, seq_dict in unique_seq_counts.items():
    with open(f"{sample_name}_unique_sequences.txt", "w") as unique_file:
        unique_file.write("Sequence\tCount\n")
        for sequence, count in seq_dict.items():
            unique_file.write(f"{sequence}\t{count}\n")

print("Sorting and combining complete. Read assignment counts and output files have been created.")
