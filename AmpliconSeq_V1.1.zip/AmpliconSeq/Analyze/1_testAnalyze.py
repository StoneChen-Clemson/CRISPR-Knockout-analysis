import pandas as pd
from Bio import SeqIO
from Bio.Seq import Seq
import os

def pad_to_codon_length(sequence):
    """Pad the sequence with 'N' (up to 2 bases) so its length is a multiple of 3."""
    remainder = len(sequence) % 3
    if remainder != 0:
        sequence += 'N' * (3 - remainder)
    return sequence

def process_fastq(row):
    fastq_file = row['fastq_file']
    if not fastq_file.lower().endswith('.fastq'):
        fastq_file += '.fastq'
    fastq_file_path = os.path.join(os.getcwd(), fastq_file)

    ref_seq = row['reference_sequence']
    part_seq = row['partial_sequence']
    introns = {
        'left': row.get('left_intron', ''),
        'mid': row.get('mid_intron', ''),
        'right': row.get('right_intron', '')
    }

    # Pad and translate the reference to find its stop codon position
    padded_ref_seq = pad_to_codon_length(ref_seq)
    translated_ref_seq = Seq(padded_ref_seq).translate(to_stop=False)
    ref_stop_codon_index = str(translated_ref_seq).find('*')  # -1 if no stop codon in reference

    WT_count = 0
    Indel_count = 0
    splicing_mut_count = 0
    
    # Track Indel lengths
    Indel_lengths = {}
    
    # Track stop codon changes
    truncation_count = 0
    amino_acid_mutation_count = 0
    no_stop_codon_count = 0
    
    total_reads = 0

    try:
        for record in SeqIO.parse(fastq_file_path, 'fastq'):
            total_reads += 1
            read_seq = str(record.seq)
            is_splicing_mut = False

            # Count if the partial sequence is intact -> treat as WT
            if part_seq in read_seq:
                WT_count += 1
            else:
                # It's an indel
                Indel_count += 1
                indel_length = len(read_seq) - len(part_seq)
                Indel_lengths[indel_length] = Indel_lengths.get(indel_length, 0) + 1

                # Check splicing sites
                if (introns['left'] and not read_seq.startswith(introns['left'])) or \
                   (introns['right'] and not read_seq.endswith(introns['right'])) or \
                   (introns['mid'] and introns['mid'] not in read_seq):
                    is_splicing_mut = True
                    splicing_mut_count += 1

                # Only proceed to check stop codon positions if not a splicing mutation
                if not is_splicing_mut:
                    # Remove introns from the read sequence if present in expected positions
                    if introns['left'] and read_seq.startswith(introns['left']):
                        read_seq = read_seq[len(introns['left']):]
                    if introns['mid'] and introns['mid'] in read_seq:
                        read_seq = read_seq.replace(introns['mid'], '', 1)
                    if introns['right'] and read_seq.endswith(introns['right']):
                        read_seq = read_seq[:-len(introns['right'])]

                    # Similarly modify the partial reference piece for alignment
                    modified_part_seq = part_seq
                    if introns['left'] and modified_part_seq.startswith(introns['left']):
                        modified_part_seq = modified_part_seq[len(introns['left']):]
                    if introns['mid'] and introns['mid'] in modified_part_seq:
                        modified_part_seq = modified_part_seq.replace(introns['mid'], '', 1)
                    if introns['right'] and modified_part_seq.endswith(introns['right']):
                        modified_part_seq = modified_part_seq[:-len(introns['right'])]

                    # Insert the read sequence back into the reference
                    start_index = ref_seq.find(modified_part_seq)
                    end_index = start_index + len(modified_part_seq)
                    if start_index != -1 and end_index != -1:
                        read_seq = ref_seq[:start_index] + read_seq + ref_seq[end_index:]

                    # Pad the read to a multiple of 3, then translate
                    read_seq = pad_to_codon_length(read_seq)
                    translated_seq = Seq(read_seq).translate(to_stop=False)
                    read_stop_codon_index = str(translated_seq).find('*')  # -1 if no stop codon

                    # Compare stop codon positions
                    if read_stop_codon_index == -1:
                        # No stop codon at all
                        no_stop_codon_count += 1
                    else:
                        # If reference has no stop codon at all, any found stop is effectively a "mutation"
                        if ref_stop_codon_index == -1:
                            amino_acid_mutation_count += 1
                        else:
                            # Compare to reference stop codon position
                            if read_stop_codon_index < ref_stop_codon_index:
                                truncation_count += 1
                            elif read_stop_codon_index > ref_stop_codon_index:
                                amino_acid_mutation_count += 1
                            # if read_stop_codon_index == ref_stop_codon_index,
                            # treat it as same as reference (already accounted for in overall classification).
    except FileNotFoundError:
        print(f"File not found: {fastq_file_path}")
        return

    # Prepare data for output
    data = [
        ('WT_count', WT_count),
        ('WT_percentage', WT_count / total_reads * 100 if total_reads else 0),
        ('Indel_count', Indel_count),
        ('Indel_percentage', Indel_count / total_reads * 100 if total_reads else 0),
        ('uncharacterized splice site-proximal intronic mutation', splicing_mut_count),  # ? ???
        ('truncation_count', truncation_count),
        ('amino_acid_mutation_count', amino_acid_mutation_count),
        ('no_stop_codon_count', no_stop_codon_count),
    ]
    
    # Add per-Indel-length counts
    for length, count in Indel_lengths.items():
        data.append((f'Indel_length_diff_{length}', count))
    
    df = pd.DataFrame(data, columns=['Statistic', 'Value'])
    output_filename = os.path.splitext(os.path.basename(fastq_file))[0] + '_output.csv'
    df.to_csv(output_filename, index=False)

# Load the CSV
df = pd.read_csv('AddSequence.csv').fillna('')

# Process each row in the CSV
for index, row in df.iterrows():
    process_fastq(row)
