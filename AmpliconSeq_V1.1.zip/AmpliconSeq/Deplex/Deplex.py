import csv
import re
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
import glob

def pattern_to_regex(pattern):
    """Converts a nucleotide pattern into a regex object, treating 'N' as any nucleotide."""
    return re.compile(pattern.replace('N', '[ATCG]'))

def contained_pattern_to_regex(pattern):
    """Creates a regex object for the contain pattern, 'N' matches any nucleotide."""
    if pattern:
        return re.compile(pattern.replace('N', '[ATCG]'))
    else:
        return None  # No contain pattern provided

# Read demultiplexing patterns, sample names, and contain patterns from CSV
patterns = {}
with open('Demultiplex.csv', 'r') as csvfile:
    reader = csv.reader(csvfile)
    next(reader, None)  # Skip the header
    for row in reader:
        sample_name, start_pattern, contain_pattern = row
        patterns[(pattern_to_regex(start_pattern), contained_pattern_to_regex(contain_pattern))] = sample_name

# Initialize counters and open output files
total_counters = {sample_name: 0 for sample_name in set(patterns.values())}
output_files = {sample_name: open(f"{sample_name}.fastq", "a") for sample_name in total_counters}

# Create a dictionary to store counts per FASTQ file
file_counters = {}

# List the names of generated output FASTQ files
output_fastq_filenames = {f"{sample_name}.fastq" for sample_name in total_counters}

# Process each FASTQ file in the directory, excluding generated output files
for fastq_file_name in glob.glob("*.fastq"):
    if fastq_file_name in output_fastq_filenames:  # Skip output FASTQ files
        continue

    file_counters[fastq_file_name] = {sample_name: 0 for sample_name in total_counters}
    unassigned = 0
    with open(fastq_file_name, "r") as fastq_file:
        for record in SeqIO.parse(fastq_file, "fastq"):
            seq = str(record.seq)
            assigned = False
            for (start_pattern, contain_pattern), sample_name in patterns.items():
                match_start = start_pattern.search(seq)

                if match_start:
                    if contain_pattern:
                        # Process with both StartPattern and ContainPattern
                        match_contain = contain_pattern.search(seq, match_start.end())
                        if match_contain:
                            # Extract the sequence between StartPattern and ContainPattern
                            between_seq = seq[match_start.end():match_contain.start()]
                            new_record = SeqRecord(Seq(between_seq),
                                                   id=record.id,
                                                   name=record.name,
                                                   description=record.description)
                            # Adjust quality scores if present
                            if "phred_quality" in record.letter_annotations:
                                between_qual = record.letter_annotations["phred_quality"][match_start.end():match_contain.start()]
                                new_record.letter_annotations["phred_quality"] = between_qual

                            # Write to the sample-specific file
                            SeqIO.write(new_record, output_files[sample_name], "fastq")
                            total_counters[sample_name] += 1
                            file_counters[fastq_file_name][sample_name] += 1
                            assigned = True
                            break  # Break after the first match
                    else:
                        # Process with only StartPattern (no ContainPattern)
                        trimmed_seq = seq[match_start.end():]
                        new_record = SeqRecord(Seq(trimmed_seq),
                                               id=record.id,
                                               name=record.name,
                                               description=record.description)
                        # Adjust quality scores if present
                        if "phred_quality" in record.letter_annotations:
                            trimmed_qual = record.letter_annotations["phred_quality"][match_start.end():]
                            new_record.letter_annotations["phred_quality"] = trimmed_qual

                        # Write to the sample-specific file
                        SeqIO.write(new_record, output_files[sample_name], "fastq")
                        total_counters[sample_name] += 1
                        file_counters[fastq_file_name][sample_name] += 1
                        assigned = True
                        break  # Break after the first match
            if not assigned:
                unassigned += 1

    file_counters[fastq_file_name]["Unassigned"] = unassigned

# Close all output files
for file in output_files.values():
    file.close()

# Write read assignment counts to a summary file
with open("read_assignment_counts.txt", "w") as counts_file:
    counts_file.write("Per File Read Assignment Counts:\n")
    for fastq_file, counts in file_counters.items():
        counts_file.write(f"File: {fastq_file}\n")
        for sample_name, count in counts.items():
            counts_file.write(f"  {sample_name}: {count} reads\n")
        counts_file.write("\n")

    counts_file.write("Total Read Assignment Counts:\n")
    for sample_name, count in total_counters.items():
        counts_file.write(f"{sample_name}: {count} reads\n")

print("Sorting and combining complete. Read assignment counts and output files have been created.")
