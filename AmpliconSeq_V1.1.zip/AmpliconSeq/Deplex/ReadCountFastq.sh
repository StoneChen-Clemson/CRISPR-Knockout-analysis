#!/bin/bash

# Get the current working directory
FASTQ_DIR=$(pwd)

# Define the output file
OUTPUT_FILE="${FASTQ_DIR}/read_counts_summary.txt"

# Start fresh with the output file or create it if it doesn't exist
: > "$OUTPUT_FILE"

# Loop through each .fastq file in the current directory
for FULL_PATH in "${FASTQ_DIR}"/*.fastq
do
  # Extract just the file name from the path
  FILENAME=$(basename "$FULL_PATH")

  # Check if the file exists
  if [ ! -f "$FULL_PATH" ]; then
    echo "File not found: $FULL_PATH" >> "$OUTPUT_FILE"
    continue
  fi

  # Debug: show the full path it's trying to access
  echo "Checking file: $FULL_PATH"

  # Count the number of lines in the file
  LINE_COUNT=$(wc -l < "$FULL_PATH")

  # Each read consists of 4 lines, calculate the number of reads
  READ_COUNT=$((LINE_COUNT / 4))

  # Output the result to the output file
  echo "File: $FILENAME has $READ_COUNT reads" >> "$OUTPUT_FILE"
done

echo "Read counts have been summarized in $OUTPUT_FILE"
